# Import the DatabaseOperator class
from database_tests import DatabaseOperator
import sqlite3

# Create a connection to the SQLite database
conn = sqlite3.connect('test2.db')

# Create an instance of the DatabaseOperator class
db_operator = DatabaseOperator(conn)

# Add a record
db_operator.add_record(1001, "John", "Doe", 30, "Valencia")

# Update a record
db_operator.update_record(1000, "Jane", "Doe", 35, "Sydney")  # Assuming the record with ID 1 exists

# Delete a record
db_operator.delete_record(999)  # Assuming the record with ID 999 exists

# Get all records
records = db_operator.get_record()
for record in records:
    print(record)

# Close the database connection
db_operator.close_connection()
