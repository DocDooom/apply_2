import sqlite3

class DatabaseOperator:
    
    def __init__(self, conn: sqlite3.Connection) -> None:
        # Connect to the SQLite database file
        # self.conn = sqlite3.connect('test1.db')
        self.cursor = conn.cursor()

    def get_record(self):
        cursor = self.conn.cursor()
        cursor.execute(" SELECT * FROM person; ")
        records = cursor.fetchall()
        return records

    def add_record(self, id, first_name, last_name, age, city):
        self.cursor.execute("INSERT INTO person (id, first_name, last_name, age, city) VALUES (?, ?, ?, ?, ?);", (id, first_name, last_name, age, city))
        self.conn.commit()

    def update_record(self, id, new_first_name, new_last_name, new_age, new_city):
        self.cursor.execute("UPDATE person SET first_name = ?, last_name = ?, age = ?, city = ? WHERE id = ?;", (id, new_first_name, new_last_name, new_age, new_city))
        self.conn.commit()

    def delete_record(self, person_id):
        self.cursor.execute("DELETE FROM person WHERE id = ?;", (person_id,))
        self.conn.commit()

    def close_connection(self):
        # Close the connection when done
        self.conn.close()